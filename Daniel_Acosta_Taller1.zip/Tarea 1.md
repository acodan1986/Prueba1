# TALLER 1. VISUALIZACIÓN RMARKDOWN

## Presentado por: Daniel Arturo Acosta Gaitan

### El objetivo es identificar elementos de una visualización basados en el framework de Tamara para lograr la compresión de todos los componentes claves aprendidos en clase. Para ello el estudiante debe elegir mínimo dos visualizaciones realizadas y publicadas en alguna entidad oficial (ej: páginas gubernamentales, entidades privadas, medios públicos) y analizarlas, cada una, bajo los siguientes criterios: 

* Abstraer ¿qué?, ¿por qué? y ¿cómo?
* Marcas y canales utilizados
* Cumple o no cumple alguna de las reglas generales descritas
* Mejoras posibles, en cuánto a marcas o canales, que le realizaría a la visualización

## Primer ejemplo.

En el la siguiente imagen se muestra una infografía presentada por el ministerio de salud acerca de un resumen diario sobre el acumulado de casos confirmados, recuperados y número de muertos. Para el numero de casos acumulados tambien estan discriminados de acuerdo al lugar del pais en donde fueron detectados. Asi mismo en la parte inferior se muestra información adicional referente al recuento mundial de casos confirmados, recuperados y fallecidos.

![Imagen tomada de: https://www.minsalud.gov.co/salud/publica/PET/Paginas/Covid-19_copia.aspx ](attachment:250221_post_coronavirus_baja.jpg)

*Imagen tomada de https://www.minsalud.gov.co/salud/publica/PET/Paginas/Covid-19_copia.aspx*

### 1. Identificación de elementos

### WHAT?

#### DataSet

- Se puede apreciar que el elemento principal de esta vizualización es un dataset de tipo geometria (espacial) el cual es el mapa de Colombia y donde se ubican el acumulado de casos detectados para cada departamento del país.


![1.jpg](attachment:1.jpg)

- La información proporcionada muestra una instantanea del momento en que fueron recolectados los datos, y permite ver las zonas del pais con mayores casos de coronavirus.

- La disponibilidad del dataset es estatica dado que no se permite ver la evolución del numero de casos reportados en el tiempo.

### WHY?

#### Acciones

- ***Analizar*** esta viz la pondria en el termino de **presentar** ya trata de explicar la situación actual del coronavirus en Colombia y el mundo.

- La acción principal que personalmente asignaria a esta vizualizacion seria el ***Search*** más especificamente en la palabra **explorar** ya un usuario que vea esta imagen por primera vez y no tenga un contexto de la misma no tendria una licalización ni  un objetivo especifico de interes.

![2.jpg](attachment:2.jpg)

#### Target

- El objetivo principal de esta visualización es plasmar unos datos espaciales, ya que no se pueden identificar jerarquias ni tendencias en los mismos.

### HOW?

- **Encode** uso de un marco espacial.
    - **Color** manejo del color para hacer enfasis en elementos de interes.
        - **Navigate** De este modo se facilita la visualización.

### 2. Marcas y canales

#### Marcas

- El rasgo fundamental de esta visualizacion se centra en el uso de formas para organizar la información y presentarla (formas geometricas y mapa).

#### Canales

- Se aprecia canales de **posición** para organizar los datos.
- El canal del **color** se observa con dos colores prediminantes, azul y fucsia. El azul como base y el fucsia para resaltar cosas importantes.

#### Eficiencia

- Se observa cierta interferencia que no permite separar elementos, fondo de la infografia no aporta nada a la misma y hace perder efectividad a la hora de mostrar la información.

### 3. Cumplimiento de las reglas

### Uso injustificado del 3D

- El contraste y saturación entre el mapa y el fondo terminan creando un efecto 3D que no aporta nada a la visualización y termina siendo un elemento distractor.


### Uso del 2D

- Fue buena idea haber hecho uso del mapa, sin embargo la organización de los labels en el mismo generan distracciones y modifican la escencia de tener un mapa, (por ejemplo el label de cundinamarca quedo ubicado en el oceano pacifico), esto a mi modo de ver crea distracción y dificulta el analisis de las cifras.

### Función vs forma

- Personalmente siento que le dio mucha más importancia a la forma que a la función y utilidad de la visualización porque se terminan mostrando unos datos estaticos que no permiten tener un panorama de la evolución de la enfermedad en el pais. 




### 4. Mejoras posibles

Para esta visualización realizaria los siguientes cambios:

- Alteraria el **canal** del color para eliminar el efecto 3D, y usaria colores menos saturados que permitan hacer enfasis en las cifras presentadas.
- En lugar de labels en el mapa usaria una escala de colores (mapa de calor) para mostrar los departamentos mas y menos afectados por el covid.


## Segundo Ejemplo

En la siguiente visualización presentada por el periodico El Tiempo, se muestra un gráfico de lineas y puntos donde se observa la evolución en el tiempo de la cantidad de vacunados contra el covid que se registran en el país.

![vacunacion.jpg](attachment:vacunacion.jpg)

*Imagen tomada de https://www.eltiempo.com/salud/en-vivo-el-avance-de-la-vacunacion-en-colombia-568805*

####  1. Identificación de elementos

### WHAT?

#### Dataset

El dataset es de tipo temporal y esta expresado a partir de datos tabulados en un gráfico de lineas y puntos, enmarcados bajos los valores de referencia en los ejes.

- Se esta mostrando de manera secuencial la evolución de la variable "vacunas aplicadas".



![3.jpg](attachment:3.jpg)

### WHY?

#### Acciones

- Uno de los verbos principales seria el de **presentar** ya que plasma los datos para que puedan ser analizados por alguien.

- Dentro del **Search** la acción que para mi seria la que más se acerca seria el *look up* porque los datos son faciles de interpretar debido a la simpicidad de los mismos.

- Asi mismo dentro de **Query** yo lo ubicaria en el item de identificar porque permite saber en que dias se aplicaron mayor o menor numero de vacunas.

![4-2.jpg](attachment:4-2.jpg)

#### Target

Claramente el objetivo principal de esta visualización es identificar la tendencia que se presenta a lo largo del tiempo referencia a la velocidad de la vacunación en Colombia.

![5.jpg](attachment:5.jpg)

### HOW?

- **Encode** 
    - Arrange
        - Order: Ordenamiento cronologico del acumuladode la variable.


#### 2. Marcas y canales

#### Marcas

- El rasgo fundamental de esta visualizacion son las lineas y puntos que forman los ejes del gráfico y muestran los cambios en los valores de la variable.

#### Canales

- Se aprecia canales de **posición** tanto en el eje horizontal como vertical.
- El canal del **color** se usa de manera discreta pero efectiva ya que resalta los datos que son necesarios ver.
- **Forma** el uso de puntos para marcar el inicio y final de la serie de tiempo.

#### Presición

- Se observa que el uso de canales de tamaño y saturación en este ejemplo juegan a favor en la presentación con claridad en la información.



### 3. Cumplimiento de las reglas


### Uso del 2D

- El 2D esta bien justificado en este ejemplo y permite un mejor análisis de los datos, a si estuvieran simplemente en una tabla.

### Los ojos le ganan a la memoria

- Por la misma razón anterior este grafico 2D es mas efectivo para comprender rapidamente la idea que se trata de transmitir, caso contrario a presentar una tabla que requeriria tiempo y pasos adicionales para interpretar los datos.

### 4. Mejoras posibles

En general esta vizualización me parecio muy buena y solo agregaria un pequeño cambio:

- Alteraria la **marca** para incluir puntos intermedios que marquen todos los dias del rango temporal, esto con el fin de facilitar aun más la claridad y legibilidad de la imagen.
